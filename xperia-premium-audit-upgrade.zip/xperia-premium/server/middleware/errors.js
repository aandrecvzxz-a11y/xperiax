export function notFound(_req,res){res.status(404).json({error:'Endpoint tidak ditemukan.'});}
export function errorHandler(err,_req,res,_next){console.error('[server-error]',err?.message||'unknown'); if(res.headersSent)return; res.status(err.status||500).json({error:err.status&&err.status<500?err.message:'Terjadi kesalahan pada server. Coba lagi nanti.'});}
