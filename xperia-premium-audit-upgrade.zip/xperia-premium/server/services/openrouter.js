import 'dotenv/config';

const keys = () => [
  process.env.OPENROUTER_API_KEY_1,
  process.env.OPENROUTER_API_KEY_2,
  process.env.OPENROUTER_API_KEY_3,
  process.env.OPENROUTER_API_KEY_4,
  process.env.OPENROUTER_API_KEY, // backward compatibility
].map(v => typeof v === 'string' ? v.trim() : '').filter(Boolean);
let cursor = 0;

export async function chat({ messages, model, signal }) {
  const available = keys();
  if (!available.length) throw Object.assign(new Error('AI belum dikonfigurasi. Tambahkan minimal satu OPENROUTER_API_KEY_1 sampai OPENROUTER_API_KEY_4 di environment server.'), { status: 503 });
  const models = [model, process.env.OPENROUTER_MODEL, process.env.OPENROUTER_FALLBACK_MODEL]
    .map(v => typeof v === 'string' ? v.trim() : '').filter((v, i, a) => v && a.indexOf(v) === i);
  if (!models.length) throw Object.assign(new Error('OPENROUTER_MODEL belum dikonfigurasi.'), { status: 503 });

  let last = null;
  modelLoop: for (const selectedModel of models) {
    for (let attempt = 0; attempt < available.length; attempt++) {
      const idx = (cursor + attempt) % available.length;
      const controller = new AbortController();
      const abortFromCaller = () => controller.abort();
      if (signal) signal.addEventListener('abort', abortFromCaller, { once: true });
      const timer = setTimeout(() => controller.abort(), 30000);
      try {
        const base = (process.env.OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1').replace(/\/+$/, '');
        const r = await fetch(`${base}/chat/completions`, {
          method: 'POST', signal: controller.signal,
          headers: {
            Authorization: `Bearer ${available[idx]}`, 'Content-Type': 'application/json',
            'HTTP-Referer': process.env.OPENROUTER_HTTP_REFERER || process.env.APP_URL || 'http://localhost:3000',
            'X-Title': process.env.OPENROUTER_APP_TITLE || 'XPERIA PREMIUM',
          },
          body: JSON.stringify({ model: selectedModel, messages: messages.slice(-24).map(m => ({ ...m, content: m.content.slice(-12000) })), stream: false }),
        });
        if (r.ok) {
          let data;
          try { data = await r.json(); } catch { last = { status: 502, message: 'OpenRouter mengirim respons sukses yang bukan JSON.' }; break modelLoop; }
          const content = data?.choices?.[0]?.message?.content;
          if (typeof content !== 'string' || !content.trim()) { last = { status: 502, message: 'OpenRouter tidak mengembalikan teks jawaban.' }; break modelLoop; }
          cursor = (idx + 1) % available.length;
          return { text: content, model: data.model || selectedModel };
        }
        const body = await r.json().catch(() => ({}));
        last = { status: r.status, message: body?.error?.message || body?.message || `OpenRouter returned HTTP ${r.status}` };
        // These are configuration/billing failures, not transient failures; do not rotate/retry them.
        if ([400, 401, 402, 403].includes(r.status)) break modelLoop;
        // A model-specific 404 should try the next configured model, not retry the same model with every key.
        if (r.status === 404) break;
        // Rotate key for rate limits and transient provider/server failures only.
        if (![429, 500, 502, 503, 504].includes(r.status)) break modelLoop;
      } catch (e) {
        last = { status: 504, message: e.name === 'AbortError' ? 'Permintaan AI melewati batas waktu.' : 'Layanan AI tidak dapat dijangkau.' };
        if (signal?.aborted) break modelLoop;
      } finally {
        clearTimeout(timer);
        if (signal) signal.removeEventListener('abort', abortFromCaller);
      }
    }
  }
  const safeMessage = last?.status === 401 || last?.status === 403
    ? 'API key OpenRouter ditolak. Periksa environment variables di server.'
    : last?.status === 402 ? 'Saldo atau kredit OpenRouter tidak mencukupi.'
    : last?.status === 404 ? 'Model OpenRouter tidak ditemukan atau tidak tersedia untuk akun ini. Periksa OPENROUTER_MODEL dan OPENROUTER_FALLBACK_MODEL.'
    : last?.status === 429 ? 'Batas penggunaan AI tercapai. Coba lagi nanti atau periksa limit provider.'
    : last?.status === 400 ? 'Request ditolak OpenRouter. Periksa model dan format pesan.'
    : last?.message || 'Semua jalur AI gagal.';
  const status = [400, 401, 402, 403, 404, 429].includes(last?.status) ? last.status : 502;
  throw Object.assign(new Error(safeMessage), { status });
}

export function keyStatus() { return keys().length; }
