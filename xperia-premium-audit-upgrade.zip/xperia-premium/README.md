# XPERIA PREMIUM

Website full-stack React + Vite + TypeScript dan Node.js + Express. Fitur meliputi dashboard tema, AI OpenRouter, MultiChat lokal, GET HTML dengan perlindungan SSRF dasar, pemeriksaan format NIK, perkiraan operator dari prefix, dan integrasi WhatsApp.

## Prasyarat
- Node.js 20+ dan npm
- `yt-dlp` terpasang di server untuk fitur TikTok/Instagram. Extractor pihak ketiga dapat berubah dan tidak menjamin semua URL publik bisa diproses.
- Satu atau lebih API key OpenRouter untuk AI.

## Instalasi
1. Salin `.env.example` menjadi `.env` di root project.
2. Isi minimal satu `OPENROUTER_API_KEY_1`; isi model seperti `openai/gpt-4o-mini` (hapus spasi awal/akhir).
3. Jalankan `npm install`, `npm install --prefix server`, dan `npm install --prefix client`.
4. Jalankan `npm run dev` dari root. Frontend berjalan di `http://localhost:5173`, API di `http://localhost:3000`.

## Production
- Jalankan `npm run build` untuk membangun frontend ke `client/dist`.
- Deploy frontend ke static host seperti Vercel/Netlify dan backend Express ke layanan Node.js seperti Render, Railway, VPS, atau container. Atur `CLIENT_URL` ke origin frontend dan `APP_URL`/`OPENROUTER_HTTP_REFERER` sesuai domain deployment.
- Frontend menggunakan `/api` relatif melalui proxy Vite saat development. Untuk deployment frontend dan backend pada domain berbeda, atur reverse proxy `/api` ke backend atau sesuaikan base URL di `client/src` serta CORS `CLIENT_URL`.
- Database belum diperlukan untuk fungsi inti; riwayat MultiChat disimpan di `localStorage` browser dan tidak tersinkron ke cloud atau lintas perangkat. Jangan menganggap ini autentikasi akun.

## Environment
- `OPENROUTER_API_KEY_1` sampai `_4`: key server-side. Backend memutar key antar request dan mencoba key lain/model fallback saat error yang sesuai. Ini bukan cara melewati kuota atau kebijakan provider.
- `OPENROUTER_MODEL`: model utama, contoh `openai/gpt-4o-mini`.
- `OPENROUTER_FALLBACK_MODEL`: model fallback opsional.
- `OPENROUTER_BASE_URL`: default `https://openrouter.ai/api/v1`.
- `SESSION_SECRET` dan `DATABASE_URL` disediakan sebagai titik awal untuk penambahan auth/database; saat ini autentikasi pengguna dan database cloud belum diimplementasikan.

## Downloader
Backend menjalankan `yt-dlp --dump-single-json` melalui executable yang tersedia pada PATH. Install yt-dlp pada mesin server dan ikuti ketentuan platform serta hak pemilik konten. Tidak memakai API key pengguna, tetapi bergantung pada tool eksternal dan perubahan situs. File URL hasil extractor berasal dari provider dan ditampilkan sebagai tautan; downloader tidak melakukan proxy streaming file. Konten privat, login-gated, atau yang dibatasi tidak didukung.

## Keamanan dan batasan
- Helmet, rate limiting umum, validasi Zod pada endpoint utama, batas body JSON, penanganan error terpusat, serta timeout dan limit ukuran GET HTML.
- GET HTML memvalidasi DNS/IP dan setiap redirect, memblokir IP non-unicast, tidak meneruskan cookie/auth, dan tidak menjalankan HTML target. Untuk produksi berisiko tinggi, tambahkan egress firewall, pinning DNS pada koneksi, isolasi proses, observability dan pengujian SSRF khusus; pemeriksaan DNS aplikasi saja tidak dapat menjamin mitigasi DNS rebinding di semua lingkungan.
- AI API key tidak dikirim ke browser. Jangan memasukkan secret ke Vite env dengan prefiks `VITE_`.
- NIK hanya diperiksa format panjang/digit. Tidak ada verifikasi Dukcapil dan tidak ada lookup identitas.
- Operator adalah perkiraan prefix dan bisa tidak sesuai jika nomor berpindah jaringan.
- Tidak ada autentikasi server untuk saat ini. Jangan gunakan endpoint ini sebagai layanan publik multi-user tanpa menambahkan auth, isolasi data, kebijakan kuota dan monitoring.

## Testing
Jalankan `npm test` untuk tes unit dasar di server. Jalankan `npm run build` untuk TypeScript check dan production build. Pengujian ini tidak menggantikan pengujian integrasi dengan OpenRouter/yt-dlp dan security testing deployment.

## Perubahan audit dan batasan penting
- AI OpenRouter kini hanya menggunakan model yang diminta atau dikonfigurasi (`OPENROUTER_MODEL`, `OPENROUTER_FALLBACK_MODEL`), membatasi konteks ke 24 pesan terakhir, menangani respons non-JSON/kosong, dan tidak memutar key untuk kesalahan permanen (401/402/403/400). Key tetap hanya dibaca di backend.
- GET HTML hanya menerima respons bertipe HTML/XHTML dan status sukses; respons non-HTML atau HTTP error dikembalikan sebagai JSON error. Konten dibatasi 1 MB dan ditampilkan sebagai teks, bukan dieksekusi.
- NIK memeriksa panjang, pola tanggal dan tanggal kalender (termasuk tahun kabisat), menampilkan kode wilayah, gender indikatif, dan nomor urut. Untuk nama wilayah, UI meminta hanya kode wilayah (bukan NIK penuh, tanggal lahir, atau nomor urut) ke API publik Wilayah.id; jika layanan tidak tersedia, nama wilayah ditandai belum tersedia. Dataset tersebut menyatakan pembaruan 4 Juli 2025, jadi cek sumber sebelum penggunaan resmi. Referensi: https://wilayah.id/ dan https://data.go.id/dataset/dataset/data-rekapitulasi-kode-data-wilayah-administrasi-pemerintahan-per-provinsi. Hasil bukan verifikasi Dukcapil.
- Text to QR Code dibuat lokal di browser menggunakan `qrcode.react`; teks tidak dikirim ke backend. Mendukung unduh PNG/SVG, ukuran dan warna.
- Downloader menggunakan `execFile` dengan argumen terpisah (tanpa shell) dan memerlukan executable `yt-dlp` yang benar-benar tersedia pada host. Runtime Vercel serverless umumnya tidak menyediakan binary tersebut secara otomatis; gunakan layanan Node.js/container terpisah yang menginstal yt-dlp jika downloader dibutuhkan.
- Riwayat chat masih disimpan di localStorage browser; autentikasi dan database cloud belum diimplementasikan. Jangan gunakan sebagai layanan multi-user publik tanpa kontrol akses dan penyimpanan terisolasi.

## Pemeriksaan lokal
`node --check server/app.js`, `node --check server/services/openrouter.js`, dan `node --test server/validators.test.js` dapat dijalankan tanpa memanggil layanan eksternal. `npm run build` membutuhkan instalasi dependency yang berhasil. Build belum dapat dinyatakan lulus hanya dari pemeriksaan sintaks.
